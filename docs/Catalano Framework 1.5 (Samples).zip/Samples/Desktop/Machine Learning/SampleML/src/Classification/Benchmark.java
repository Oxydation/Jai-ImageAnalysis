/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classification;

import Catalano.MachineLearning.BenchmarkClassifier;
import Catalano.MachineLearning.Classification.DecisionTrees.Learning.RandomForest;
import Catalano.MachineLearning.Classification.IClassifier;
import Catalano.MachineLearning.Classification.KNearestNeighbors;
import Catalano.MachineLearning.Classification.MulticlassSupportVectorMachine;
import Catalano.MachineLearning.DatasetClassification;
import Catalano.MachineLearning.Performance.HoldoutValidation;
import Catalano.Math.Distances.ChiSquareDistance;
import Catalano.Math.Distances.EuclideanDistance;
import Catalano.Math.Distances.JensenShannonDivergence;
import Catalano.Math.Distances.KumarJohnsonDivergence;
import Catalano.Statistics.Kernels.Gaussian;
import Catalano.Statistics.Kernels.Pearson;
import java.util.ArrayList;
import java.util.List;

/**
 * Third example, run several classifiers, and get the best classifier.
 * @author Diego
 */
public class Benchmark {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //Load iris dataset
        DatasetClassification dataset = DatasetClassification.FromCSV("iris.csv", "Iris");
        
        //Normalize the data
        dataset.Normalize();
        
        //Input and output data
        double[][] input = dataset.getInput();
        int[] output = dataset.getOutput();
        int n = dataset.getNumberOfClasses();
        
        //Create a list of classifiers
        List<IClassifier> lst = new ArrayList<>();
        lst.add(new KNearestNeighbors(5, new EuclideanDistance()));
        lst.add(new KNearestNeighbors(5, new ChiSquareDistance()));
        lst.add(new KNearestNeighbors(5, new JensenShannonDivergence()));
        lst.add(new KNearestNeighbors(5, new KumarJohnsonDivergence()));
        lst.add(new MulticlassSupportVectorMachine(new Gaussian(100), 1, n));
        lst.add(new MulticlassSupportVectorMachine(new Pearson(), 1, n));
        lst.add(new RandomForest());
        
        BenchmarkClassifier bc = new BenchmarkClassifier(input, output);
        bc.Compute(lst, new HoldoutValidation());
        
        IClassifier bestClassifier = bc.getBestClassifier();
        double[] rank = bc.getRank();
        
        System.out.println("Winner: " + bestClassifier.getClass().getSimpleName());
        System.out.println("");
        for (int i = 0; i < rank.length; i++) {
            System.out.println(rank[i]);
        }
    }
}