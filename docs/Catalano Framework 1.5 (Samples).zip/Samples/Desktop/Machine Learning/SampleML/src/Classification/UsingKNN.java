/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classification;

import Catalano.MachineLearning.Classification.KNearestNeighbors;
import Catalano.MachineLearning.DatasetClassification;
import Catalano.Math.Distances.EuclideanDistance;

/**
 * First example using KNN.
 * @author Diego Catalano
 */
public class UsingKNN {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //Load iris dataset
        DatasetClassification dataset = DatasetClassification.FromCSV("iris.csv", "Iris");
        
        //Normalize the data
        dataset.Normalize();
        
        //Input and output data
        double[][] input = dataset.getInput();
        int[] output = dataset.getOutput();
        
        //Initialize a classifier
        KNearestNeighbors knn = new KNearestNeighbors(3, new EuclideanDistance());
        
        //Learn
        knn.Learn(input, output);
        
        //Predict some feature
        int p = knn.Predict(new double[] {4.5,3.2,4.5,3.6});
        
        System.out.println(p);
        
    }
    
}
